function Create(self)
	self.HitsMOs = true
end
