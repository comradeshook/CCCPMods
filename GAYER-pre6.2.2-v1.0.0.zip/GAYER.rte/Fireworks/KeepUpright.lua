function Create(self)
	self.RotAngle = math.rad(90);
	self.HFlipped = false;
end
