function Create(self)
	self.RotAngle = 0
end
