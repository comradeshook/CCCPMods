function Update(self)
	if self.RotAngle ~= 0.785 then
		self.RotAngle = 0.785
		self.HFlipped = false
	end
end
