function Create(self)
	self.Mass = 1000
	self.DeepCheck = 1
end
