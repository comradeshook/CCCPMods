function Update(self)
	self.Vel = self.Vel * 0.95
end
