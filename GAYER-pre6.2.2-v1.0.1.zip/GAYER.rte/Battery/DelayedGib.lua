function Update(self)
	if self.Age > 2000 then
		self:GibThis()
	end
end
