function Create(self)
	print(self.Mass);
end